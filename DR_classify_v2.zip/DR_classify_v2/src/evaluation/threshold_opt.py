"""
QWK-optimal decision thresholds (post-hoc, fit on validation only).

RetiNA_Net.predict() outputs a (B, num_classes) probability distribution
(a 0.7/0.3 blend of the classification and ordinal heads). The obvious way
to turn that into a hard grade prediction is argmax — but argmax implicitly
treats every misclassification as equally bad, while Quadratic Weighted
Kappa (the primary metric for ordinal DR grading, and the one used
throughout this project's logs) explicitly penalizes distant errors more
than adjacent ones.

A better decision rule: convert the probability distribution to an
"expected grade" (its mean under the predicted distribution), which is a
continuous ordinal-aware score, then find 4 cut-points on that continuous
score that directly maximize QWK on the validation set. This is standard
practice in ordinal DR-grading literature (used in the original Kaggle
APTOS/EyePACS competitions and in most published ordinal-regression DR
papers) and typically adds 1-3 QWK points over naive argmax, "for free" —
no retraining required.

IMPORTANT: thresholds must be fit ONLY on validation data and then applied,
unchanged, to the test/external set. Fitting them on the test set would be
a form of test-set leakage.
"""

import numpy as np
from scipy.optimize import minimize
from sklearn.metrics import cohen_kappa_score


def probs_to_expected_grade(probs: np.ndarray) -> np.ndarray:
    """probs: (N, num_classes) -> (N,) expected grade = sum_k k * P(y=k)."""
    num_classes = probs.shape[1]
    grade_values = np.arange(num_classes)
    return probs @ grade_values


def _apply_thresholds(scores: np.ndarray, thresholds: np.ndarray, num_classes: int) -> np.ndarray:
    """Bucket continuous scores into integer grades using sorted cut-points."""
    thresholds = np.sort(thresholds)
    preds = np.zeros_like(scores, dtype=int)
    for t in thresholds:
        preds += (scores > t).astype(int)
    return np.clip(preds, 0, num_classes - 1)


def fit_qwk_thresholds(val_probs: np.ndarray, val_targets: np.ndarray,
                        num_classes: int = 5, n_restarts: int = 8, seed: int = 42):
    """
    Search for the (num_classes - 1) cut-points on expected-grade scores that
    maximize QWK on (val_probs, val_targets). Uses Nelder-Mead from several
    random initializations (the QWK-vs-threshold surface is non-convex and
    piecewise-constant, so a single local optimizer run can get stuck).

    Returns:
        best_thresholds: sorted np.ndarray of shape (num_classes - 1,)
        best_qwk: the QWK achieved by best_thresholds on the validation set
    """
    scores = probs_to_expected_grade(val_probs)
    rng = np.random.RandomState(seed)

    def neg_qwk(thresholds):
        preds = _apply_thresholds(scores, thresholds, num_classes)
        return -cohen_kappa_score(val_targets, preds, weights="quadratic")

    # Default/naive initialization: midpoints between integer grades (0.5, 1.5, ...)
    init_default = np.arange(0.5, num_classes - 1 + 0.5, 1.0)

    best_thresholds, best_qwk = None, -np.inf
    inits = [init_default] + [
        init_default + rng.uniform(-0.3, 0.3, size=num_classes - 1) for _ in range(n_restarts - 1)
    ]
    for init in inits:
        result = minimize(neg_qwk, init, method="Nelder-Mead",
                           options={"xatol": 1e-4, "fatol": 1e-4, "maxiter": 2000})
        qwk = -result.fun
        if qwk > best_qwk:
            best_qwk = qwk
            best_thresholds = np.sort(result.x)

    naive_preds = np.clip(np.round(scores).astype(int), 0, num_classes - 1)
    naive_qwk = cohen_kappa_score(val_targets, naive_preds, weights="quadratic")

    return best_thresholds, best_qwk, naive_qwk


def apply_qwk_thresholds(probs: np.ndarray, thresholds: np.ndarray, num_classes: int = 5) -> np.ndarray:
    """Apply previously-fit thresholds to new (e.g. test/external) probabilities."""
    scores = probs_to_expected_grade(probs)
    return _apply_thresholds(scores, thresholds, num_classes)
