import torch
import torch.nn as nn
import numpy as np
import logging
from tqdm import tqdm

from .tta import predict_with_tta, predict_multiscale_tta
from .metrics import compute_metrics

logger = logging.getLogger(__name__)


class EnsembleModel(nn.Module):
    """
    Ensemble of multiple models (e.g., K-fold models).

    Averages softmax probabilities across all models, then takes argmax.
    This reduces prediction variance and typically yields 2-5% accuracy
    improvement over a single model.
    """

    def __init__(self, models, weights=None):
        """
        Args:
            models: List of trained models
            weights: Optional list of weights for each model (default: equal)
        """
        super().__init__()
        self.models = nn.ModuleList(models)
        if weights is None:
            self.weights = [1.0 / len(models)] * len(models)
        else:
            total = sum(weights)
            self.weights = [w / total for w in weights]

    def forward(self, x):
        """
        Forward pass through all models, averaging probabilities.
        Returns dict with 'logits' (averaged) and 'ordinal_logits' (averaged).
        """
        all_probs_cls = []
        all_ord_probs = []

        for model in self.models:
            out = model(x)
            if isinstance(out, dict):
                cls_probs = torch.softmax(out['logits'], dim=1)
                all_probs_cls.append(cls_probs)

                if out.get('ordinal_logits') is not None:
                    from ..models.components import OrdinalRegressionHead
                    ord_probs = OrdinalRegressionHead.ordinal_logits_to_class_probs(out['ordinal_logits'])
                    all_ord_probs.append(ord_probs)

        # Weighted average of classification probabilities
        avg_cls_probs = sum(w * p for w, p in zip(self.weights, all_probs_cls))

        # Weighted average of ordinal probabilities (if available)
        if all_ord_probs:
            avg_ord_probs = sum(w * p for w, p in zip(self.weights, all_ord_probs))
            # Combine classification and ordinal — 0.7/0.3 (classification dominant)
            final_probs = 0.7 * avg_cls_probs + 0.3 * avg_ord_probs
        else:
            final_probs = avg_cls_probs

        # Convert back to logits for compatibility
        final_logits = torch.log(final_probs + 1e-8)

        return {
            'logits': final_logits,
            'ordinal_logits': None,
            'probs': final_probs
        }

    def predict(self, x):
        """Return final probabilities."""
        out = self.forward(x)
        return out['probs']


@torch.no_grad()
def ensemble_predict(models, dataloader, device, use_tta=True,
                     use_multiscale=False, scales=(0.9, 1.0, 1.1),
                     use_flips=True, use_rotations=True, weights=None,
                     center_crops=(0.9, 0.95)):
    """
    Run ensemble inference on a dataloader.

    Args:
        models: List of trained models
        dataloader: DataLoader to evaluate on
        device: torch.device
        use_tta: Whether to use TTA
        use_multiscale: Whether to use multi-scale TTA
        scales: Scales for multi-scale TTA
        use_flips: Include flips in TTA
        use_rotations: Include rotations in TTA
        weights: Optional weights for each model

    Returns:
        all_preds, all_targets, all_probs
    """
    if weights is None:
        weights = [1.0 / len(models)] * len(models)
    else:
        total = sum(weights)
        weights = [w / total for w in weights]

    all_preds = []
    all_targets = []
    all_probs = []

    for model in models:
        model.to(device)
        model.eval()

    for inputs, targets in tqdm(dataloader, desc="Ensemble inference"):
        inputs = inputs.to(device)
        batch_probs = torch.zeros(inputs.size(0), 5, device=device)

        for model, weight in zip(models, weights):
            if use_multiscale:
                probs, _ = predict_multiscale_tta(
                    model, inputs, scales=scales,
                    use_flips=use_flips, use_rotations=use_rotations,
                    center_crops=center_crops
                )
            else:
                probs, _ = predict_with_tta(
                    model, inputs, use_tta=use_tta,
                    use_flips=use_flips, use_rotations=use_rotations
                )
            batch_probs += weight * probs

        preds = torch.argmax(batch_probs, dim=1)

        all_preds.extend(preds.cpu().numpy())
        all_targets.extend(targets.numpy())
        all_probs.extend(batch_probs.cpu().numpy())

    return all_preds, all_targets, all_probs


def load_ensemble_models(model_class, model_paths, device, **model_kwargs):
    """
    Load multiple model checkpoints into separate model instances.

    Args:
        model_class: Model class (e.g., RetiNA_Net)
        model_paths: List of checkpoint paths
        device: torch.device
        **model_kwargs: Additional model constructor arguments

    Returns:
        List of loaded models
    """
    models = []
    for path in model_paths:
        model = model_class(**model_kwargs).to(device)
        state_dict = torch.load(path, map_location=device)

        # Handle SWA models that may have different BN stats
        model.load_state_dict(state_dict)
        model.eval()
        models.append(model)
        logger.info(f"Loaded model from {path}")

    return models


def evaluate_ensemble(models, dataloader, device, use_tta=True,
                      use_multiscale=False, scales=(0.9, 1.0, 1.1),
                      use_flips=True, use_rotations=True, weights=None,
                      center_crops=(0.9, 0.95)):
    """
    Evaluate ensemble and return metrics.

    Args:
        models: List of trained models
        dataloader: DataLoader to evaluate on
        device: torch.device
        use_tta: Whether to use TTA
        use_multiscale: Whether to use multi-scale TTA
        scales: Scales for multi-scale TTA
        use_flips: Include flips in TTA
        use_rotations: Include rotations in TTA
        weights: Optional weights for each model

    Returns:
        metrics dict
    """
    all_preds, all_targets, all_probs = ensemble_predict(
        models, dataloader, device,
        use_tta=use_tta, use_multiscale=use_multiscale, scales=scales,
        use_flips=use_flips, use_rotations=use_rotations, weights=weights,
        center_crops=center_crops
    )

    metrics = compute_metrics(all_targets, all_preds)
    return metrics, all_preds, all_targets, all_probs


# ============================================================================
# Architecturally diverse ensembling (config.yaml: use_diverse_ensemble)
#
# The single-architecture ensemble above (EnsembleModel / evaluate_ensemble)
# combines K-fold models that all share the SAME backbone — diversity only
# comes from the different train/val splits. Diversity in inductive bias
# (SwinV2's shifted-window attention vs. ConvNeXt's large-kernel convolutions
# vs. EfficientNet's compound-scaled MBConv blocks) tends to buy MORE
# ensemble gain than fold diversity alone, because the architectures make
# genuinely different kinds of errors rather than correlated ones.
#
# Each architecture in config.yaml's `ensemble_architectures` is trained
# independently (its own 5-fold CV, using main.py as normal with `--backbone`
# / `--backbone-channels` overridden per architecture — see run_diverse_
# ensemble_training in main.py). This module then combines their OUT-OF-FOLD
# (OOF) probability predictions into a single stacked prediction.
# ============================================================================

def fit_stacking_meta_learner(oof_probs_per_arch, targets, num_classes: int = 5):
    """
    Fit a stacking meta-learner on out-of-fold probabilities from N
    architecturally diverse models.

    Args:
        oof_probs_per_arch: dict {arch_name: np.ndarray of shape (N_samples, num_classes)},
            each array being that architecture's OUT-OF-FOLD predicted
            probabilities (i.e. each sample's prediction came from a fold
            that did NOT train on it — using in-fold predictions here would
            leak and inflate the meta-learner's apparent performance).
        targets: (N_samples,) integer ground-truth grades, aligned with the
            row order of every array in oof_probs_per_arch.

    Returns:
        A fitted sklearn LogisticRegression meta-learner. Its input is the
        concatenation of all architectures' per-class probabilities
        (N_samples, num_classes * num_architectures); its output is the
        final class prediction. This generally beats fixed-weight averaging
        because it can learn, e.g., "trust ConvNeXt more on class 3" rather
        than only a single global weight per architecture.
    """
    from sklearn.linear_model import LogisticRegression

    arch_names = sorted(oof_probs_per_arch.keys())
    stacked_features = np.concatenate([oof_probs_per_arch[name] for name in arch_names], axis=1)

    meta_learner = LogisticRegression(max_iter=2000, multi_class="multinomial")
    meta_learner.fit(stacked_features, targets)
    meta_learner.arch_names_ = arch_names  # remember the expected input order
    return meta_learner


def stacking_predict(meta_learner, probs_per_arch):
    """
    Apply a fitted stacking meta-learner to new (e.g. test/external) per-
    architecture probabilities.

    Args:
        meta_learner: output of fit_stacking_meta_learner
        probs_per_arch: dict {arch_name: (N_samples, num_classes) array},
            must contain the same architecture names used at fit time.

    Returns:
        preds: (N_samples,) predicted class labels
        probs: (N_samples, num_classes) predicted class probabilities
    """
    arch_names = meta_learner.arch_names_
    missing = [n for n in arch_names if n not in probs_per_arch]
    if missing:
        raise ValueError(f"stacking_predict missing architectures the meta-learner was fit on: {missing}")

    stacked_features = np.concatenate([probs_per_arch[name] for name in arch_names], axis=1)
    preds = meta_learner.predict(stacked_features)
    probs = meta_learner.predict_proba(stacked_features)
    return preds, probs


def average_ensemble_predict(probs_per_arch, weights=None):
    """
    Simple fallback: equal- or manually-weighted probability averaging
    across architectures (config.yaml: ensemble_stacking: "average").
    Use this if you don't have enough OOF data to fit a meta-learner
    reliably, or want a simpler, more interpretable combination rule.
    """
    arch_names = sorted(probs_per_arch.keys())
    if weights is None:
        weights = {name: 1.0 / len(arch_names) for name in arch_names}
    total = sum(weights[name] * probs_per_arch[name] for name in arch_names)
    preds = np.argmax(total, axis=1)
    return preds, total
