"""
Sharpness-Aware Minimization (SAM).

Reference: Foret, P., Kleiner, A., Mobahi, H., & Neyshabur, B. (2021).
"Sharpness-Aware Minimization for Efficiently Improving Generalization." ICLR 2021.

SAM seeks parameters that lie in neighborhoods having uniformly low loss
(flat minima), rather than parameters that merely achieve low loss at a
single point. This is done by:
  1. Computing an "ascent step" epsilon = rho * grad / ||grad||, and moving
     to w + epsilon (the worst-case point in the local neighborhood).
  2. Computing the gradient AT w + epsilon.
  3. Stepping the base optimizer using that gradient, from the ORIGINAL w.

Flat minima generalize better than sharp minima, and the effect is most
pronounced in small-data / large-model regimes — exactly the regime this
project is in (SwinV2-Large fine-tuned on ~2,900 images/fold). This is why
it's included in the plan rather than, e.g., a purely architectural change.

Usage (see trainer.py for the full integration with AMP + grad accumulation):

    base_optimizer = torch.optim.AdamW
    optimizer = SAM(model.parameters(), base_optimizer, rho=0.05, lr=..., weight_decay=...)

    # first forward-backward pass
    loss = criterion(model(inputs), targets)
    loss.backward()
    optimizer.first_step(zero_grad=True)

    # second forward-backward pass (SAM requires two)
    criterion(model(inputs), targets).backward()
    optimizer.second_step(zero_grad=True)

Note: SAM roughly doubles step time (two forward-backward passes per
optimizer step). With gradient accumulation, apply SAM's two steps only on
the accumulation boundary (i.e., once per *effective* batch), not on every
micro-batch — see trainer.py's `use_sam` branch in `train_epoch`.
"""

import torch


class SAM(torch.optim.Optimizer):
    def __init__(self, params, base_optimizer, rho=0.05, adaptive=False, **kwargs):
        assert rho >= 0, f"Invalid rho, should be non-negative: {rho}"

        defaults = dict(rho=rho, adaptive=adaptive, **kwargs)
        super(SAM, self).__init__(params, defaults)

        self.base_optimizer = base_optimizer(self.param_groups, **kwargs)
        self.param_groups = self.base_optimizer.param_groups
        self.defaults.update(self.base_optimizer.defaults)

    @torch.no_grad()
    def first_step(self, zero_grad=False):
        """Ascent step: move to the worst-case point w + epsilon in the local neighborhood."""
        grad_norm = self._grad_norm()
        for group in self.param_groups:
            scale = group["rho"] / (grad_norm + 1e-12)

            for p in group["params"]:
                if p.grad is None:
                    continue
                self.state[p]["old_p"] = p.data.clone()
                e_w = (torch.pow(p, 2) if group["adaptive"] else 1.0) * p.grad * scale.to(p)
                p.add_(e_w)  # climb to the local maximum "w + e(w)"

        if zero_grad:
            self.zero_grad()

    @torch.no_grad()
    def second_step(self, zero_grad=False):
        """Descent step: restore original weights, then step the base optimizer
        using the gradient computed at the perturbed point."""
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None:
                    continue
                p.data = self.state[p]["old_p"]  # get back to "w" from "w + e(w)"

        self.base_optimizer.step()  # actual SAM update happens here

        if zero_grad:
            self.zero_grad()

    @torch.no_grad()
    def step(self, closure=None):
        # Not used directly — call first_step()/second_step() explicitly in the
        # training loop, since SAM requires two forward-backward passes and a
        # single `step(closure)` call can't cleanly interleave with AMP scaling
        # and gradient accumulation the way this codebase's trainer does it.
        raise RuntimeError(
            "SAM.step() is not supported directly — call first_step() after the "
            "first backward() and second_step() after the second backward(). "
            "See trainer.py's train_epoch() for the integration."
        )

    def _grad_norm(self):
        shared_device = self.param_groups[0]["params"][0].device
        norm = torch.norm(
            torch.stack([
                ((torch.abs(p) if group["adaptive"] else 1.0) * p.grad).norm(p=2).to(shared_device)
                for group in self.param_groups for p in group["params"]
                if p.grad is not None
            ]),
            p=2
        )
        return norm

    def load_state_dict(self, state_dict):
        super().load_state_dict(state_dict)
        self.base_optimizer.param_groups = self.param_groups
