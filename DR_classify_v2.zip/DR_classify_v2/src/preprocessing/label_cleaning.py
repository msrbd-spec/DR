"""
Label cleaning via confident learning (cleanlab).

WHY: APTOS-2019's labels come from a SINGLE Kaggle grader per image, not an
adjudicated multi-specialist consensus. Krause et al. (2018, Ophthalmology)
show even trained ophthalmologists disagree with a consensus reference
standard at QWK 0.80-0.84 — so a meaningful fraction of single-grader labels
in any DR dataset are likely to be borderline or simply wrong, especially
between adjacent severity classes. Regularizing harder (dropout, SAM, label
smoothing) helps the model tolerate this noise, but it doesn't fix it. This
script directly identifies probable label errors instead.

HOW: confident learning (Northcutt, Jiang & Chuang, 2021, "Confident
Learning: Estimating Uncertainty in Dataset Labels," JAIR) uses a trained
classifier's out-of-fold (OOF) predicted probabilities to estimate, for each
class pair (i, j), how often examples truly of class i are confidently
predicted as class j. This builds an estimated joint distribution of
label noise, which is then used to rank individual training examples by how
likely their GIVEN label is wrong — without needing any ground truth beyond
what the classifier itself learned.

USAGE (run AFTER an initial 5-fold model has been trained — this is NOT
part of the normal train/test entrypoints in main.py, it's a separate
offline analysis + relabeling step):

    python -m src.preprocessing.label_cleaning \
        --oof-probs results/oof_probs_proposed.npy \
        --oof-targets results/oof_targets_proposed.npy \
        --train-csv datasets/APTOS_19/train_1.csv \
        --output results/label_cleaning_report.csv

The OOF probs/targets should come from concatenating each fold's
val-set predictions across all 5 folds (i.e. every training image gets
exactly one prediction, from the one fold that did NOT train on it).
main.py's train_kfold() already saves per-fold predictions to
`results/` — see the loader helper below for the expected format, or
adapt `load_oof_predictions` to your actual saved format.

OUTPUT: a CSV ranking training images by estimated label-error likelihood,
plus (depending on config.yaml's label_cleaning.action_on_flagged) either:
  - "reweight": a sample-weight file usable by CombinedLoss(sample_weights=...)
    to down-weight (not remove) flagged images during a re-training run
  - "drop": a filtered train_1.csv with flagged images removed entirely

Reweighting is the default and is the more conservative choice — it lets
the model still learn from ambiguous images (at reduced influence) rather
than assuming the automated flagging is always correct and discarding data.
"""

import argparse
import logging

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def run_confident_learning(oof_probs: np.ndarray, oof_targets: np.ndarray):
    """
    Args:
        oof_probs: (N, num_classes) out-of-fold predicted probabilities
        oof_targets: (N,) given (possibly noisy) integer labels

    Returns:
        label_issue_mask: (N,) bool array, True where cleanlab flags the
            given label as likely wrong
        label_quality_scores: (N,) float array in [0, 1], lower = more
            likely to be a label error (see cleanlab docs for exact semantics)
    """
    try:
        import cleanlab
        from cleanlab.filter import find_label_issues
        from cleanlab.rank import get_label_quality_scores
    except ImportError as e:
        raise ImportError(
            "cleanlab is required for label cleaning: pip install cleanlab. "
            "(Added to requirements.txt in this update.)"
        ) from e

    label_issue_mask = find_label_issues(
        labels=oof_targets,
        pred_probs=oof_probs,
        return_indices_ranked_by="self_confidence",
        filter_by="prune_by_noise_rate",
    )
    # find_label_issues with return_indices_ranked_by returns an array of
    # indices, not a mask, when that argument is set — convert for consistency.
    if label_issue_mask.dtype != bool:
        mask = np.zeros(len(oof_targets), dtype=bool)
        mask[label_issue_mask] = True
        label_issue_mask = mask

    label_quality_scores = get_label_quality_scores(labels=oof_targets, pred_probs=oof_probs)

    logger.info(
        "Confident learning flagged %d / %d (%.1f%%) training labels as likely errors.",
        label_issue_mask.sum(), len(oof_targets), 100 * label_issue_mask.mean()
    )
    return label_issue_mask, label_quality_scores


def build_sample_weights(image_ids, label_issue_mask, reweight_factor: float = 0.3) -> dict:
    """
    Turns a flagged-label mask into a {image_id: weight} dict for
    CombinedLoss(sample_weights=...). Flagged images get `reweight_factor`
    (default 0.3, i.e. 30% of their normal gradient contribution); everything
    else gets weight 1.0.

    NOTE: full wiring of per-sample weights into the training loop requires
    the Dataset/DataLoader to also return each sample's image_id/index (so
    the trainer can look up its weight at batch time). This is not yet
    threaded through src/data/ in this update — CombinedLoss accepts
    `sample_weights` as a documented hook, but datamodule.py's Dataset
    class needs a small change (return index alongside (image, label)) to
    actually use it end-to-end. That's a deliberately separate, reviewable
    change rather than bundled silently into this label-cleaning script.
    """
    weights = {img_id: 1.0 for img_id in image_ids}
    for img_id, flagged in zip(image_ids, label_issue_mask):
        if flagged:
            weights[img_id] = reweight_factor
    return weights


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oof-probs", required=True, help="Path to .npy file, shape (N, num_classes)")
    parser.add_argument("--oof-targets", required=True, help="Path to .npy file, shape (N,)")
    parser.add_argument("--train-csv", required=True, help="Path to train_1.csv (for image_id alignment)")
    parser.add_argument("--output", default="results/label_cleaning_report.csv")
    parser.add_argument("--reweight-factor", type=float, default=0.3)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    oof_probs = np.load(args.oof_probs)
    oof_targets = np.load(args.oof_targets)
    train_df = pd.read_csv(args.train_csv)

    assert len(oof_probs) == len(train_df), (
        f"OOF prediction count ({len(oof_probs)}) doesn't match train_1.csv row count "
        f"({len(train_df)}) — make sure oof_probs/oof_targets were built by "
        "concatenating ALL 5 folds' val predictions in the SAME row order as train_1.csv."
    )

    label_issue_mask, label_quality_scores = run_confident_learning(oof_probs, oof_targets)

    id_column = "id_code" if "id_code" in train_df.columns else train_df.columns[0]
    report = pd.DataFrame({
        "image_id": train_df[id_column],
        "given_label": oof_targets,
        "predicted_label": oof_probs.argmax(axis=1),
        "label_quality_score": label_quality_scores,
        "flagged_as_likely_error": label_issue_mask,
    }).sort_values("label_quality_score")

    report.to_csv(args.output, index=False)
    logger.info("Wrote label-cleaning report to %s", args.output)

    weights = build_sample_weights(train_df[id_column].tolist(), label_issue_mask, args.reweight_factor)
    weights_path = args.output.replace(".csv", "_sample_weights.csv")
    pd.DataFrame({"image_id": list(weights.keys()), "weight": list(weights.values())}).to_csv(
        weights_path, index=False
    )
    logger.info("Wrote per-sample reweighting file to %s", weights_path)


if __name__ == "__main__":
    main()
