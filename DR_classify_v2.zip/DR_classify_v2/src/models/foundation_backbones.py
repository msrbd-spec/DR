"""
Retina-domain foundation model backbones: RETFound and FLAIR.

WHY: your own Phase-3 SSL pretraining runs contrastive + lesion-guided
multi-task pretraining on EyePACS (~88,702 unlabeled images). That's a
reasonable amount of data, but public retina foundation models were
pretrained on substantially more:

  - RETFound (Zhou et al., Nature 2023, "A foundation model for generalizable
    disease detection from retinal images") — ViT-Large pretrained via masked
    autoencoding (MAE) on ~1.6M retinal images. A calibration-benchmark study
    (PMC13128382) reports RETFound reaching QWK 0.884 on APTOS with just a
    frozen-backbone linear/MLP head — i.e. a strong prior even with zero
    task-specific engineering on top.

  - FLAIR (Silva-Rodríguez et al., Medical Image Analysis 2024, "A foundation
    language-image model of the retina") — CLIP-style vision-language
    pretraining across a large multi-dataset retinal corpus, encoding expert
    textual knowledge (e.g. clinical descriptions of DR severity) as part of
    the visual representation.

IMPORTANT / WHAT YOU STILL NEED TO DO: this sandbox cannot download model
weights (huggingface.co and the RETFound/FLAIR release hosts are not on this
environment's network allowlist). This module gives you the LOADING CODE and
the ADAPTER that makes either backbone produce the same interface RetiNA_Net
expects from timm's `features_only=True` SwinV2 (a list of 4 stage feature
maps). You still need to, on your own machine:

  1. Download the RETFound checkpoint from the official repo:
     https://github.com/rmaphoh/RETFound_MAE
     (look for RETFound_cfp_weights.pth, trained on color fundus photography)
  2. OR download FLAIR weights from:
     https://github.com/jusiro/FLAIR
  3. Set `foundation_checkpoint_path` in config.yaml to the local path.

CAVEAT ViT backbones are NOT naturally multi-scale/pyramidal the way SwinV2
is — a plain ViT produces one resolution of patch tokens throughout. So
MSDA (designed for spatial deformable attention across stages) and HFF
(designed to fuse 4 differently-scaled feature maps) don't have a natural
equivalent here. FoundationBackboneAdapter fakes a 4-stage interface by
taking intermediate transformer block outputs at 4 different depths and
reshaping tokens back into a spatial grid — this lets the *rest* of
RetiNA_Net's pipeline (MSDA/HFF/heads) run unmodified for a fair
architecture comparison, but note this is an adapter, not a claim that
ViT's intermediate blocks are equivalent to a CNN/Swin's spatial stages.
If you want a cleaner ViT-native head, set `use_msda: False, use_hff: False`
in config.yaml when backbone_type is retfound/flair and let the model use
pooled stage-4 features directly (still fully supported by RetiNA_Net).
"""

import torch
import torch.nn as nn


class FoundationBackboneAdapter(nn.Module):
    """
    Wraps a ViT-style foundation model (RETFound or FLAIR's image encoder) so
    its forward() returns a 4-element list of (B, H, W, C) feature maps, the
    same interface RetiNA_Net expects from timm SwinV2 with features_only=True.

    Implementation: takes transformer block outputs at 4 evenly-spaced depths
    (e.g. blocks 6, 12, 18, 24 of a 24-block ViT-Large), drops the [CLS]
    token, and reshapes the remaining patch tokens from (B, N, C) back to a
    spatial grid (B, H, W, C) using the known patch size / image size.
    """

    def __init__(self, vit_backbone: nn.Module, embed_dim: int, img_size: int, patch_size: int):
        super().__init__()
        self.vit = vit_backbone
        self.embed_dim = embed_dim
        self.grid_size = img_size // patch_size
        n_blocks = len(self.vit.blocks)
        # 4 evenly spaced tap points across the transformer depth
        self.tap_indices = sorted(set(
            max(1, round(n_blocks * frac)) - 1 for frac in (0.25, 0.5, 0.75, 1.0)
        ))
        while len(self.tap_indices) < 4:
            self.tap_indices.append(self.tap_indices[-1])

    def _tokens_to_grid(self, tokens: torch.Tensor) -> torch.Tensor:
        # tokens: (B, 1 + N, C) with a leading [CLS] token -> (B, H, W, C)
        if tokens.shape[1] == self.grid_size ** 2 + 1:
            tokens = tokens[:, 1:, :]
        b, n, c = tokens.shape
        h = w = self.grid_size
        assert n == h * w, (
            f"Unexpected token count {n} for grid {h}x{w}={h*w}; check img_size/patch_size."
        )
        return tokens.reshape(b, h, w, c)

    def forward(self, x):
        # Re-implements timm ViT's forward_features loop so we can tap
        # intermediate blocks, instead of only getting the final output.
        vit = self.vit
        tokens = vit.patch_embed(x)
        if hasattr(vit, "_pos_embed"):
            tokens = vit._pos_embed(tokens)
        else:  # pragma: no cover - fallback for older timm versions
            cls_token = vit.cls_token.expand(tokens.shape[0], -1, -1)
            tokens = torch.cat((cls_token, tokens), dim=1) + vit.pos_embed

        outputs = []
        for i, block in enumerate(vit.blocks):
            tokens = block(tokens)
            if i in self.tap_indices:
                outputs.append(self._tokens_to_grid(tokens))
        while len(outputs) < 4:
            outputs.append(outputs[-1])
        return outputs[-4:]


def build_retfound_backbone(checkpoint_path: str, img_size: int = 512):
    """
    Loads a RETFound (ViT-Large, MAE-pretrained) checkpoint and wraps it in
    FoundationBackboneAdapter. Requires `checkpoint_path` to exist locally —
    see this module's docstring for where to download it.
    """
    import timm

    if not checkpoint_path or not __import__("os").path.exists(checkpoint_path):
        raise FileNotFoundError(
            f"RETFound checkpoint not found at '{checkpoint_path}'. Download it from "
            "https://github.com/rmaphoh/RETFound_MAE and set "
            "config.yaml -> foundation_checkpoint_path to the local file. "
            "This cannot be fetched automatically in this environment."
        )

    # RETFound is architecturally a standard ViT-Large/16; timm can build the
    # skeleton, we then overwrite weights with the RETFound checkpoint.
    vit = timm.create_model(
        "vit_large_patch16_224", pretrained=False, img_size=img_size, num_classes=0
    )
    state_dict = torch.load(checkpoint_path, map_location="cpu")
    state_dict = state_dict.get("model", state_dict)  # RETFound ckpts nest under "model"
    missing, unexpected = vit.load_state_dict(state_dict, strict=False)
    print(f"[RETFound] loaded checkpoint from {checkpoint_path}: "
          f"{len(missing)} missing keys, {len(unexpected)} unexpected keys.")

    return FoundationBackboneAdapter(vit, embed_dim=vit.embed_dim, img_size=img_size, patch_size=16)


def build_flair_backbone(checkpoint_path: str, img_size: int = 512):
    """
    Loads FLAIR's vision encoder and wraps it in FoundationBackboneAdapter.
    FLAIR is CLIP-style (image + text encoders); only the image encoder is
    used here since RetiNA_Net's downstream heads are purely visual.
    Requires `checkpoint_path` to exist locally — see this module's docstring.
    """
    import timm

    if not checkpoint_path or not __import__("os").path.exists(checkpoint_path):
        raise FileNotFoundError(
            f"FLAIR checkpoint not found at '{checkpoint_path}'. Download it from "
            "https://github.com/jusiro/FLAIR and set config.yaml -> "
            "foundation_checkpoint_path to the local file. This cannot be "
            "fetched automatically in this environment."
        )

    # FLAIR's public release uses a ViT-Base/32 image encoder.
    vit = timm.create_model(
        "vit_base_patch32_224", pretrained=False, img_size=img_size, num_classes=0
    )
    state_dict = torch.load(checkpoint_path, map_location="cpu")
    # FLAIR checkpoints typically prefix visual-tower weights; adjust the
    # prefix below if the specific release you download differs.
    visual_prefix = "visual."
    visual_state = {
        k[len(visual_prefix):]: v for k, v in state_dict.items() if k.startswith(visual_prefix)
    }
    state_to_load = visual_state if visual_state else state_dict
    missing, unexpected = vit.load_state_dict(state_to_load, strict=False)
    print(f"[FLAIR] loaded checkpoint from {checkpoint_path}: "
          f"{len(missing)} missing keys, {len(unexpected)} unexpected keys.")

    return FoundationBackboneAdapter(vit, embed_dim=vit.embed_dim, img_size=img_size, patch_size=32)
