import logging
import os
import torch
import torch.nn as nn
import timm

from .components import (
    MSDABlock, HFFBlock, MultiScaleHead, OrdinalRegressionHead, CoralHead, AuxHead
)
from .foundation_backbones import build_retfound_backbone, build_flair_backbone

logger = logging.getLogger(__name__)



class RetiNA_Net(nn.Module):
    """
    RetiNA-Net: Retinal Neural Architecture Network.

    A custom DR classification network combining:
      - SwinV2-Large backbone (pretrained, features_only)
      - MSDA: Multi-Scale Deformable Attention on Stage 3 & 4
      - HFF: Hierarchical Feature Fusion (Stage 1 → Stage 4, all 4 stages)
      - Spatial Attention Pooling head
      - Deep supervision auxiliary head
      - Ordinal regression head

    Architecture:
      - Backbone: SwinV2-Large (pretrained, features_only)
      - MSDA: Multi-Scale Deformable Attention on Stage 3 & 4
      - HFF: Hierarchical Feature Fusion (Stage 1 → Stage 4, all 4 stages)
      - Head: Multi-scale attention pooling + 2-layer MLP
      - Aux head: Deep supervision on stage-3 features
      - Ordinal head: Optional ordinal regression head for ordinal-aware loss

    The model returns a dict with:
      - 'logits': classification logits (B, num_classes)
      - 'aux_logits': auxiliary logits (B, num_classes) or None
      - 'ordinal_logits': ordinal cumulative logits (B, num_classes-1) or None
    """

    def __init__(self, use_msda: bool = True, use_hff: bool = True,
                 num_classes: int = 5, drop_path_rate: float = 0.1,
                 dropout: float = 0.1, use_ordinal: bool = True,
                 use_aux_head: bool = True, use_attention_pool: bool = True,
                 backbone_name: str = 'swinv2_large_window12to16_192to256.ms_in22k_ft_in1k',
                 stage_channels=(192, 384, 768, 1536),
                 ssl_pretrained_path: str = None,
                 require_ssl_pretrained: bool = False,
                 backbone_type: str = "timm",
                 foundation_checkpoint_path: str = None,
                 img_size: int = 512,
                 ordinal_head_type: str = "cumulative"):
        """
        Args:
            ssl_pretrained_path: Path to SSL-pretrained backbone weights.
                                 If provided, loads these instead of ImageNet weights.
                                 Set to None to use default ImageNet pretraining.
            require_ssl_pretrained: If True and ssl_pretrained_path is set but the
                                 file doesn't exist, RAISE instead of silently
                                 falling back to ImageNet weights. This exists
                                 because an earlier version of this codebase had
                                 ssl_pretrained_path=null in config.yaml, meaning
                                 Phase-3 SSL pretraining was silently never used
                                 during fine-tuning despite being planned. Loud
                                 failure here prevents that regression from
                                 happening silently again.
            backbone_type: "timm" (default, any timm model name), "retfound",
                                 or "flair" — see src/models/foundation_backbones.py.
            ordinal_head_type: "cumulative" (original OrdinalRegressionHead) or
                                 "coral" (rank-consistent CoralHead, Cao et al. 2020).
        """
        super().__init__()
        self.use_msda = use_msda
        self.use_hff = use_hff
        self.use_ordinal = use_ordinal
        self.use_aux_head = use_aux_head
        self.num_classes = num_classes
        self.stage_channels = list(stage_channels)
        self.ordinal_head_type = ordinal_head_type

        # --- Backbone construction ---
        if backbone_type == "timm":
            # SwinV2-Large (or any other timm backbone) with dynamic image size.
            # checkpoint_in_feature_block=True: gradient checkpointing to save ~40% GPU memory
            self.backbone = timm.create_model(
                backbone_name,
                pretrained=True,  # Always load ImageNet first (ensures all params initialized)
                features_only=True,
                dynamic_img_size=True,
                img_size=img_size,
                drop_path_rate=drop_path_rate,
                checkpoint_in_feature_block=True
            )
        elif backbone_type == "retfound":
            self.backbone = build_retfound_backbone(foundation_checkpoint_path, img_size=img_size)
            # ViT foundation backbones have a single embed_dim shared across all
            # "stages" (the 4 tapped depths in FoundationBackboneAdapter are the
            # same width, unlike SwinV2's genuinely different per-stage channel
            # counts). Auto-correct stage_channels so downstream MSDA/HFF/heads
            # get consistent shapes rather than silently mismatching against
            # whatever stage_channels config.yaml happened to have set for SwinV2.
            self.stage_channels = [self.backbone.embed_dim] * 4
        elif backbone_type == "flair":
            self.backbone = build_flair_backbone(foundation_checkpoint_path, img_size=img_size)
            self.stage_channels = [self.backbone.embed_dim] * 4
        else:
            raise ValueError(f"Unknown backbone_type: {backbone_type!r} (expected 'timm', 'retfound', or 'flair')")

        self.backbone_type = backbone_type

        # --- SSL-pretrained weight loading, with a VERIFIABLE, LOUD outcome ---
        # (only meaningful for backbone_type='timm'; foundation models bring
        # their own domain pretraining and don't use this path)
        if backbone_type == "timm":
            if ssl_pretrained_path is not None:
                if os.path.exists(ssl_pretrained_path):
                    # Snapshot a few parameter norms BEFORE loading, so we can prove
                    # afterward that the weights actually changed (catches the
                    # failure mode where load_state_dict silently no-ops because of
                    # a key-name mismatch and everyone assumes SSL weights loaded).
                    sample_params = [p for p in self.backbone.parameters() if p.requires_grad][:3]
                    norms_before = [p.detach().float().norm().item() for p in sample_params]

                    ssl_state = torch.load(ssl_pretrained_path, map_location='cpu')
                    missing, unexpected = self.backbone.load_state_dict(ssl_state, strict=False)

                    norms_after = [p.detach().float().norm().item() for p in sample_params]
                    changed = any(abs(a - b) > 1e-6 for a, b in zip(norms_before, norms_after))

                    if missing:
                        logger.info("SSL backbone load: %d missing keys (expected for new layers)", len(missing))
                    if unexpected:
                        logger.info("SSL backbone load: %d unexpected keys", len(unexpected))

                    if not changed:
                        raise RuntimeError(
                            f"SSL-pretrained checkpoint at '{ssl_pretrained_path}' was loaded but "
                            "sampled backbone parameter norms did NOT change — this almost certainly "
                            "means load_state_dict silently matched zero real weights (e.g. a key-name "
                            "mismatch between the SSL checkpoint and this backbone). Refusing to "
                            "silently proceed with ImageNet-only weights while claiming SSL pretraining "
                            "was used. Check that the SSL checkpoint was saved from the SAME timm model "
                            "name/config as this backbone."
                        )
                    logger.info(
                        "Loaded SSL-pretrained backbone from %s (verified: sampled parameter "
                        "norms changed by %s)", ssl_pretrained_path,
                        [round(abs(a - b), 4) for a, b in zip(norms_before, norms_after)]
                    )
                elif require_ssl_pretrained:
                    raise FileNotFoundError(
                        f"config.yaml sets ssl_pretrained_path='{ssl_pretrained_path}' and "
                        "require_ssl_pretrained=True, but that file does not exist. Run Phase-3 "
                        "SSL pretraining first (see plan.md), or explicitly set "
                        "require_ssl_pretrained: False in config.yaml to acknowledge you are "
                        "intentionally fine-tuning from ImageNet weights only."
                    )
                else:
                    logger.warning(
                        "=" * 70 + "\n"
                        "WARNING: ssl_pretrained_path='%s' was set but the file does not exist.\n"
                        "Falling back to ImageNet-only weights. Phase-3 SSL pretraining is NOT\n"
                        "being used in this run. Set require_ssl_pretrained: True in config.yaml\n"
                        "to make this a hard error instead of a warning.\n" + "=" * 70,
                        ssl_pretrained_path
                    )
            else:
                logger.warning(
                    "ssl_pretrained_path is None — training from ImageNet weights only. "
                    "Phase-3 SSL pretraining (if you ran it) is not being used."
                )

        if self.use_msda:
            self.msda3 = MSDABlock(in_channels=self.stage_channels[2], kernel_size=3)
            self.msda4 = MSDABlock(in_channels=self.stage_channels[3], kernel_size=3)

        if self.use_hff:
            self.hff = HFFBlock(
                stage_channels=tuple(self.stage_channels),
                target_channels=self.stage_channels[3]
            )

        # Multi-scale classification head (attention pooling + 2-layer MLP)
        self.head = MultiScaleHead(
            in_channels=self.stage_channels[3],
            num_classes=num_classes,
            dropout=dropout,
            use_attention_pool=use_attention_pool
        )

        # Auxiliary head for deep supervision (on stage-3 features)
        if self.use_aux_head:
            self.aux_head = AuxHead(
                in_channels=self.stage_channels[2],
                num_classes=num_classes,
                dropout=dropout
            )

        # Optional ordinal regression head — "cumulative" (original) or "coral"
        # (rank-consistent by construction, Cao et al. 2020 — see components.py)
        if self.use_ordinal:
            head_cls = CoralHead if ordinal_head_type == "coral" else OrdinalRegressionHead
            self.ordinal_head = head_cls(
                in_channels=self.stage_channels[3],
                num_classes=num_classes,
                dropout=dropout
            )

    def forward(self, x):
        features = self.backbone(x)
        stage1 = features[0]
        stage2 = features[1]
        stage3 = features[2]
        stage4 = features[3]

        # Swin Transformers return features in (B, H, W, C) format.
        # Permute to (B, C, H, W) if the last dimension matches expected channel count.
        if stage4.shape[-1] == self.stage_channels[3]:
            stage1 = stage1.permute(0, 3, 1, 2).contiguous()
            stage2 = stage2.permute(0, 3, 1, 2).contiguous()
            stage3 = stage3.permute(0, 3, 1, 2).contiguous()
            stage4 = stage4.permute(0, 3, 1, 2).contiguous()

        # Save stage3 before MSDA for aux head
        stage3_pre_msda = stage3

        if self.use_msda:
            stage3 = self.msda3(stage3)
            stage4 = self.msda4(stage4)

        if self.use_hff:
            fused_features = self.hff(stage1, stage2, stage3, stage4)
        else:
            fused_features = stage4

        # Classification logits
        logits = self.head(fused_features)

        # Auxiliary logits (deep supervision on stage-3 pre-MSDA features)
        aux_logits = None
        if self.use_aux_head:
            aux_logits = self.aux_head(stage3_pre_msda)

        # Ordinal logits (if enabled)
        ordinal_logits = None
        if self.use_ordinal:
            ordinal_logits = self.ordinal_head(fused_features)

        return {
            'logits': logits,
            'aux_logits': aux_logits,
            'ordinal_logits': ordinal_logits
        }

    def get_classification_logits(self, x):
        """Convenience method returning only classification logits."""
        return self.forward(x)['logits']

    def predict(self, x):
        """
        Inference method returning softmax probabilities.
        Combines classification and ordinal heads for final prediction.
        Uses 0.7/0.3 weighting (classification dominant).
        """
        out = self.forward(x)
        cls_probs = torch.softmax(out['logits'], dim=1)

        if self.use_ordinal and out['ordinal_logits'] is not None:
            ord_probs = self.ordinal_head.ordinal_logits_to_class_probs(out['ordinal_logits'])
            # 70% classification, 30% ordinal — classification head is more reliable
            final_probs = 0.7 * cls_probs + 0.3 * ord_probs
        else:
            final_probs = cls_probs

        return final_probs
