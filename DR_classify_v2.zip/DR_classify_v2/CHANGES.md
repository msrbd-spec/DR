# CHANGES.md — Plan implementation log

This documents every change applied to the codebase, mapped back to the
improvement plan discussed in chat, what's fully wired vs. what still needs
one more manual step, and the honesty caveats that go with each item.

## 0. The root-cause finding

`configs/config.yaml` had `ssl_pretrained_path: null` — Phase-3 SSL
pretraining was **never actually loaded** into the fine-tuning run whose
logs were analyzed. The same config also had comments showing several
regularizers had been *deliberately weakened* in a previous pass
(`drop_path_rate` "halved — was over-regularizing", `dropout` "reduced from
0.3", `label_smoothing` "removed", `mix_prob`/`cutmix_prob` "reduced",
`focal_gamma` "reduced from 2.0"). That's the opposite of what the
overfitting diagnosis called for. This update reverses all of it and adds a
loud, unskippable verification step so the SSL-loading bug can't silently
happen again (see §1).

## 1. SSL pretrained weight loading — now verified, not silent (dr_model.py)

- `require_ssl_pretrained` config flag: if `True` and the checkpoint file is
  missing, `RetiNA_Net.__init__` now **raises** instead of silently falling
  back to ImageNet weights.
- Even when the file exists, the loader now snapshots a few backbone
  parameter norms before/after `load_state_dict` and **raises** if they
  didn't actually change — this catches the specific failure mode where
  `load_state_dict(strict=False)` silently matches zero real keys because of
  a naming mismatch, and everyone downstream assumes SSL pretraining
  happened when it didn't.
- `config.yaml` now points `ssl_pretrained_path` at
  `checkpoints/ssl_pretrained_backbone.pth`, which matches where
  `main.py`'s existing SSL pretraining entrypoint already saves its output —
  **you must run Phase-3 SSL pretraining (`main.py --mode ssl_pretrain` or
  equivalent) before your first fine-tuning run**, or this will now raise
  `FileNotFoundError` rather than quietly proceeding without it.

## 2. Regularization reverted + strengthened (config.yaml)

| Param | Old (deregularized) | New | Source |
|---|---|---|---|
| `drop_path_rate` | 0.1 | **0.3** | exceeds Herrero-Tudela's dropout discipline |
| `dropout` (head) | 0.1 | **0.5** | matches Herrero-Tudela et al.'s 0.5/0.3 dropout |
| `weight_decay` | 0.01 | **0.05** | reverted |
| `head_weight_decay` | 0.05 | **0.1** | reverted |
| `label_smoothing` | 0.0 | **0.1** | reverted + ordinal-distance mode (§4) |
| `mix_prob` | 0.1 | **0.3** | reverted |
| `cutmix_prob` | 0.3 | **0.5** | reverted |
| `focal_gamma` | 1.5 | **2.0** | reverted |
| `patience` | 25 | **12** | logs show best val QWK per fold hit by epoch ~24-37; training to 54-69 was overfitting the SWA average |
| `swa_start_epoch` | 50 | **30** | tightened to match |

## 3. Sharpness-Aware Minimization (`src/training/sam.py`, new)

Standard SAM implementation (Foret et al., ICLR 2021), no external
dependency beyond PyTorch. Wired into `trainer.py`'s `train_epoch` as an
alternate code path when `use_sam: True`.

**Caveat, stated plainly:** SAM's two-pass ascent/descent procedure doesn't
compose cleanly with AMP's `GradScaler` or with multi-microbatch gradient
accumulation without either (a) real complexity, or (b) subtly wrong
gradients. This implementation chooses correctness over cleverness: while
`use_sam=True`, gradient accumulation is bypassed (SAM runs per micro-batch,
effective batch size = `batch_size`, not `batch_size * accumulation_steps`),
and AMP's `GradScaler` isn't used in the SAM path (forward still uses
`autocast`, backward is plain fp32). A `logger.warning` fires at trainer
init if this applies to your config, so it's visible, not a silent
behavior change. Expect roughly 2x wall-clock time per epoch with SAM on.

## 4. Ordinal-distance-weighted label smoothing (`src/training/loss.py`)

**Honesty caveat, as agreed before implementing:** we do not have Krause et
al. (2018)'s exact per-class confusion matrix — only their aggregate kappa
range (retinal specialists 0.82-0.91, ophthalmologists 0.80-0.84 vs.
adjudicated consensus). `OrdinalDistanceLabelSmoothing` does NOT claim to
reproduce that matrix. It implements the qualitative pattern instead:
smoothing mass goes mostly to neighboring classes and decays geometrically
with ordinal distance (`label_smoothing_decay: 0.6`), rather than being
spread uniformly (flat smoothing) or withheld (hard one-hot). Set
`label_smoothing_mode: flat` in config.yaml if you'd rather not carry this
approximation, or `skip`-equivalent by setting `label_smoothing: 0.0`.

## 5. CORAL rank-consistent ordinal head (`src/models/components.py`, `dr_model.py`)

Added `CoralHead` (Cao, Mirjalili & Raschka, 2020) alongside the original
`OrdinalRegressionHead`. The original head learns K-1 *independent* linear
classifiers for the cumulative thresholds P(y>k), with no guarantee the
thresholds stay monotonically ordered. CORAL shares a single weight vector
across all thresholds and only learns per-threshold biases (sorted at
forward time), which guarantees rank consistency by construction. Switch via
`config.yaml: ordinal_head_type: coral` (now the default) or `cumulative`
for the original behavior.

## 6. Foundation-model backbones — RETFound / FLAIR (`src/models/foundation_backbones.py`, new)

Adds `backbone_type: retfound` / `flair` as alternatives to `timm` (SwinV2).
**You must download the actual checkpoint yourself** — this sandbox cannot
reach huggingface.co or the RETFound/FLAIR GitHub release hosts:
- RETFound: https://github.com/rmaphoh/RETFound_MAE
- FLAIR: https://github.com/jusiro/FLAIR

Set `foundation_checkpoint_path` in `config.yaml` once downloaded. A ViT
isn't naturally 4-stage/pyramidal like SwinV2, so `FoundationBackboneAdapter`
taps 4 evenly-spaced transformer block depths and reshapes tokens back into
a spatial grid so MSDA/HFF/heads can run unmodified for a fair comparison —
this is a documented adapter, not a claim those taps are equivalent to
genuine multi-scale features. If you'd rather not carry that adapter, set
`use_msda: false, use_hff: false` for foundation-model runs (fully
supported) and let stage-4 pooled features feed the heads directly.

## 7. QWK-optimal decision thresholds (`src/evaluation/threshold_opt.py`, new)

Converts the blended classification+ordinal probability output to a
continuous "expected grade" score, then fits (on validation only) the 4
cut-points that directly maximize QWK, instead of naive argmax/rounding.
Standard practice in ordinal DR-grading literature. **Not yet called from
`main.py`'s `run_test`/`run_external_validation`** — the module is complete
and tested for syntax, but wiring it into those entrypoints (fit on val
predictions, apply to test/external predictions, log before/after QWK) is
one more integration step left for you, since it touches where predictions
get cached and how per-fold vs. ensemble thresholds interact, which I didn't
want to guess at silently.

## 8. Label cleaning via confident learning (`src/preprocessing/label_cleaning.py`, new)

Offline script using `cleanlab` on out-of-fold predictions to flag likely
mislabeled APTOS images (single-grader labels, not adjudicated consensus).
Outputs a ranked report + a per-sample reweighting file.

**Partially wired, stated plainly:** `CombinedLoss` now accepts a
`sample_weights` hook, but actually applying it inside the training loop
requires the `Dataset`/`DataLoader` in `src/data/` to also return each
sample's image_id/index — that's a small, separate change to
`datamodule.py` not included here, since it touches the data-loading path
and deserved its own review rather than being bundled silently into a loss
function change. The script itself runs standalone against saved OOF
predictions regardless.

## 9. Architecturally diverse ensembling (`src/evaluation/ensemble.py`, `config.yaml`)

Added `fit_stacking_meta_learner` / `stacking_predict` (logistic-regression
meta-learner over concatenated per-architecture OOF probabilities) and
`average_ensemble_predict` (simpler weighted-average fallback). Configured
via `ensemble_architectures` in config.yaml: SwinV2-Large, ConvNeXt-Large,
EfficientNet-B4 (channel dims filled in for each). **Each architecture
still needs to be trained as its own independent 5-fold run** (same
`main.py` entrypoints, override `--backbone`/`--backbone-channels` per
architecture) — this update provides the combination logic, not a new
"train all three at once" orchestration script, since that's mostly a
shell/experiment-tracking concern rather than a modeling one.

## 10. Patient-level K-fold splitting (`config.yaml`)

Added `patient_level_split: True` and `dataset_paths.patient_id_column` to
config — guards against the paired-eye leakage risk flagged earlier (same
patient's two eyes landing in both train and val within a fold, inflating
apparent val performance). **Not yet implemented in
`src/data/datamodule.py`** — flagged in config with a clear comment, but the
actual split logic needs to know your `train_1.csv`'s real patient/eye ID
column name before I hardcode assumptions about it. Check whether that
column exists in your CSV and let me know its name if you want this wired
fully.

---

## Fully wired and ready to run as-is
Regularization reversal (§2), SAM (§3), ordinal-distance label smoothing
(§4), CORAL head (§5), SSL-loading verification (§1).

## Needs one more step from you before use
Foundation backbones (§6 — download a checkpoint), threshold optimization
(§7 — wire into main.py's test/external entrypoints), label cleaning (§8 —
add index-return to the Dataset class), diverse ensemble (§9 — train each
architecture), patient-level split (§10 — confirm your CSV's patient-ID
column name).

I scoped it this way deliberately: the changes that could be fully
specified without guessing at your data/CSV schema or your experiment
orchestration are complete; the ones that genuinely depend on details I
don't have (exact CSV columns, how you want multi-architecture training
orchestrated) are implemented as far as they safely could be, with the
remaining step spelled out rather than silently assumed.
